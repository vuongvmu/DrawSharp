// Listener.h : header file
//

#ifndef __Listener_H__
#define __Listener_H__

/////////////////////////////////////////////////////////////////////////////
// CConnectionPropertyPage dialog
extern char *sAppProtocolTypes[];
extern char *sTransProtocolTypes[];

struct Listener
{
	Listener();
	~Listener();
	CWinThread* pThread;
	SOCKET socketServer;
	int nAppProtocol, nTransProtocol;
	int nPort;
	CString strUserID, strPwd;
	CString strNextServerIP;
	int nNextServerPort;
	enum ApplicationProtocol
	{
		TYPE_HTTP = 0,
		TYPE_SOCKS4 = 1,
		TYPE_SOCKS5 = 2,
		TYPE_SMTP_SERVER = 3,
		TYPE_SMTP = 4,
		TYPE_POP3 = 5,
		TYPE_FTP = 6,
		TYPE_NNTP = 7,
		TYPE_DNS = 8,
		TYPE_CHAT_NS = 9,
		TYPE_FTP_PASV = 11,
		TYPE_FTP_PORT = 12,
		TYPE_CHAT_SB = 13
	};
	enum TransportProtocol
	{
		TYPE_TCP = 0,
		TYPE_UDP = 1,
		TYPE_ICMP = 2,
		TYPE_IGMP = 3
	};

	void StartListen();
	void StopListen();
	bool IsStarted()	{	return pThread != NULL;	}
	bool IsStoped()	{	return pThread == NULL;	}
	bool IsTemp();
};


#endif // __Listener_H__
