// Request.h : header file
//

#ifndef __Request_H__
#define __Request_H__

/////////////////////////////////////////////////////////////////////////////
// CConnectionPropertyPage dialog

struct siteInfo
{
	siteInfo()
	{
		nSent = nReceived = nRequestCount = 0;
	}
	int nSent, nReceived;
	int nRequestCount;
};

extern CPtrList gptrArryTempListeners;
extern CCriticalSection	gUserLogCS;
extern CMapStringToPtr gmapUserToSiteMap;
struct Listener;

struct Request
{
	Request();
	~Request();
public:
	SOCKET socket;
	sockaddr_in address;
	CDWordArray dwArrayHosts;
	int nLogID;
	CString strFunction;
	CString strURL, strExt, strRequest, strHost, strIP;
	int nLength;
	INTERNET_PORT nPort;
	bool bCheckBlocking;
	int nRefCount;
	CFile* pFileCache;
	bool bRequestServer;
	CFile fileLog;
	CCriticalSection csfileLog;
	CTime timeLastModified;
	int nSent, nReceived;
	CMapStringToPtr mapDomainToSocket;			//to hold unique hosts in case of Smtp Request
	int nAppProtocol, nTransProtocol;
	BOOL bLogRequest;
	Listener* pListener;
	int nTime;
};

#endif // __Request_H__
