// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__534938A9_ECF1_11D7_B8FA_0008A1444501__INCLUDED_)
#define AFX_MAINFRM_H__534938A9_ECF1_11D7_B8FA_0008A1444501__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
	int m_nMemIndex;
	int m_nSchedulesCheckTime;
	bool m_bRun;
	bool m_FirstTime;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CReBar      m_wndReBar;
	CDialogBar      m_wndDlgBar;
	NOTIFYICONDATA m_nid;
	BOOL m_bEnsureVisible;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSettings();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnAutoscroll();
	afx_msg void OnUpdateAutoscroll(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	afx_msg HRESULT OnTrayNotify(WPARAM wp, LPARAM lp);
	afx_msg void OnExit() ;
	afx_msg void OnToolsUserslog();
	afx_msg void OnRun();
	afx_msg void OnStop();
	afx_msg void OnUpdateRun(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStop(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__534938A9_ECF1_11D7_B8FA_0008A1444501__INCLUDED_)
