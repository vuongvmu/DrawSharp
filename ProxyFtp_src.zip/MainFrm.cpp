// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "LiteProxyServer.h"

#include "MainFrm.h"
#include "LiteProxyServerDoc.h"
#include "LiteProxyServerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
#define WM_NOTIFY_TRAY WM_USER+1

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_DRAWITEM()
	ON_COMMAND(ID_AUTOSCROLL, OnAutoscroll)
	ON_UPDATE_COMMAND_UI(ID_AUTOSCROLL, OnUpdateAutoscroll)
	ON_WM_CLOSE()
	ON_MESSAGE(WM_NOTIFY_TRAY, OnTrayNotify)
	ON_COMMAND(IDR_EXIT, OnExit)
	ON_COMMAND(ID_RUN, OnRun)
	ON_COMMAND(ID_STOP, OnStop)
	ON_COMMAND(ID_TRAY_STARTSERVICE, OnRun)
	ON_COMMAND(ID_TRAY_STOPSERVICE, OnStop)
	ON_UPDATE_COMMAND_UI(ID_RUN, OnUpdateRun)
	ON_UPDATE_COMMAND_UI(ID_TRAY_STOPSERVICE, OnUpdateStop)
	ON_UPDATE_COMMAND_UI(ID_TRAY_STARTSERVICE, OnUpdateRun)
	ON_UPDATE_COMMAND_UI(ID_STOP, OnUpdateStop)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_SEPARATOR,           // status line indicator
	ID_SEPARATOR,           // status line indicator
	ID_SEPARATOR,           // status line indicator
	ID_SEPARATOR,           // status line indicator
	ID_SEPARATOR,           // status line indicator
//	ID_INDICATOR_CAPS,
//	ID_INDICATOR_NUM,
//	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_nMemIndex = 0;	
	m_bRun = true;
	m_FirstTime = true;
	m_bEnsureVisible = true;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndDlgBar.Create(this, IDR_MAINFRAME, 
		CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR))
	{
		TRACE0("Failed to create dialogbar\n");
		return -1;		// fail to create
	}

	if (!m_wndReBar.Create(this) ||
		!m_wndReBar.AddBar(&m_wndToolBar) ||
		!m_wndReBar.AddBar(&m_wndDlgBar))
	{
		TRACE0("Failed to create rebar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	// memory status pane
	m_wndStatusBar.SetPaneInfo(0, ID_SEPARATOR, SBPS_NOBORDERS|SBPS_STRETCH, 50);
	m_wndStatusBar.SetPaneInfo(1, ID_SEPARATOR, SBPS_NORMAL, 80);
	m_wndStatusBar.SetPaneInfo(2, ID_SEPARATOR, SBPS_NORMAL, 120);
	m_wndStatusBar.SetPaneInfo(3, ID_SEPARATOR, SBPS_NORMAL, 120);
	m_wndStatusBar.SetPaneInfo(4, ID_SEPARATOR, SBPS_NORMAL, 120);
	m_wndStatusBar.SetPaneInfo(5, ID_SEPARATOR, SBPS_NORMAL|SBPS_OWNERDRAW, 120);

	// TODO: Remove this if you don't want tool tips
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	SetTimer(1, 1000*3, NULL);
	SetTimer(3, 1000*60*2, NULL);

//Add to Sys Tray:	
	HICON hTray = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nid.cbSize = sizeof (NOTIFYICONDATA);
	m_nid.hWnd = m_hWnd;
	m_nid.uID = 3;
	m_nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	m_nid.uCallbackMessage = WM_NOTIFY_TRAY;
	m_nid.hIcon = hTray;
	strcpy(m_nid.szTip, "EgyCom Proxy Server");
	Shell_NotifyIcon(NIM_ADD, &m_nid);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent == 1)
	{
		theApp.m_nInProgress = max(theApp.m_nInProgress, 0);
		m_wndStatusBar.SetPaneText(1, Commas(theApp.m_nInProgress)+" In progress");
		m_wndStatusBar.SetPaneText(2, Commas(theApp.m_nCacheBytes/1024)+" kb from cache");
		m_wndStatusBar.SetPaneText(3, Commas(theApp.m_nReceivedBytes/1024)+" kb received");
		m_wndStatusBar.SetPaneText(4, Commas(theApp.m_nSentBytes/1024)+" kb sent");

		MEMORYSTATUS ms;
		ms.dwLength = sizeof(MEMORYSTATUS);
		GlobalMemoryStatus(&ms);
		m_nMemIndex = min(9, (int)max(0, 9-(double)10*ms.dwAvailPhys/ms.dwTotalPhys));
		m_wndStatusBar.SetPaneText(5, Commas(ms.dwAvailPhys/1024)+" kb free");
		if(m_FirstTime)
		{
			m_FirstTime = false;
			goto CHECK_CONNECTION;
		}
	}
	else	if(nIDEvent == 3)
	{
CHECK_CONNECTION:
		CString str;
		theApp.GetConnectedState(str);
		CDocument* pDoc = GetActiveDocument();
		pDoc->SetTitle(str);
	}
	
	CFrameWnd::OnTimer(nIDEvent);
}

void CMainFrame::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	if(lpDrawItemStruct->hwndItem == m_wndStatusBar.m_hWnd)
	{
		CDC dc;
		dc.Attach(lpDrawItemStruct->hDC);
		dc.SetBkMode(TRANSPARENT);
		CString str;
		m_wndStatusBar.GetPaneText(5, str);

		dc.DrawText(str, &lpDrawItemStruct->rcItem, DT_LEFT);
		HICON icon = AfxGetApp()->LoadIcon(IDI_ICONMEM0+m_nMemIndex);
		DrawIconEx(dc.m_hDC, lpDrawItemStruct->rcItem.right-15, lpDrawItemStruct->rcItem.top, icon, 16, 16, 0, NULL, DI_NORMAL);

		dc.Detach();
	}
	else
		CFrameWnd::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CMainFrame::OnAutoscroll() 
{
	m_bEnsureVisible = !m_bEnsureVisible;

	CDocument* pDoc = GetActiveDocument();
	POSITION pos = pDoc->GetFirstViewPosition();
	((CLiteProxyServerView*)pDoc->GetNextView(pos))->m_bEnsureVisible = !m_bEnsureVisible;
}

void CMainFrame::OnUpdateAutoscroll(CCmdUI* pCmdUI) 
{
	pCmdUI->SetRadio(m_bEnsureVisible);
}

void CMainFrame::OnClose() 
{
	ShowWindow(SW_HIDE);
	
}

void CMainFrame::OnExit() 
{
	if(AfxMessageBox("Are you sure you want to shutdown the proxy server?", MB_YESNO) == IDNO)
		return;
	PostQuitMessage(0);
	Shell_NotifyIcon(NIM_DELETE, &m_nid);
	
	CFrameWnd::OnClose();
}

HRESULT CMainFrame::OnTrayNotify(WPARAM wp, LPARAM lp)
{
	UINT nMouseMsg;
	nMouseMsg = (UINT) lp;
	if(nMouseMsg == WM_LBUTTONDBLCLK)
	{
		ShowWindow(SW_SHOW);
	}
	else if(nMouseMsg == WM_RBUTTONDOWN)
	{
		CMenu menu;
		if(!menu.LoadMenu(IDR_POPMENU))
			return S_FALSE;
		CMenu *pSubMenu = menu.GetSubMenu(0);
		if(!pSubMenu)
			return S_FALSE;
		CPoint ptMouse;
		GetCursorPos(&ptMouse);
		::SetForegroundWindow(m_hWnd);
		TrackPopupMenu(pSubMenu->m_hMenu, 0, ptMouse.x, ptMouse.y, 0, m_hWnd, NULL);
	}
	return S_OK;
}

void CMainFrame::OnRun()
{
	m_bRun = true;

	CDocument* pDoc = GetActiveDocument();
	pDoc->UpdateAllViews(NULL, 0, NULL);
}

void CMainFrame::OnStop()
{
	m_bRun = false;

	CDocument* pDoc = GetActiveDocument();
	pDoc->UpdateAllViews(NULL, 1, NULL);
}

void CMainFrame::OnUpdateRun(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!m_bRun);	
}

void CMainFrame::OnUpdateStop(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_bRun);
}


