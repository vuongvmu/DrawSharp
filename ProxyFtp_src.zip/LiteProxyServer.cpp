// LiteProxyServer.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "LiteProxyServer.h"

#include "MainFrm.h"
#include "LiteProxyServerDoc.h"
#include "LiteProxyServerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerApp

BEGIN_MESSAGE_MAP(CLiteProxyServerApp, CWinApp)
	//{{AFX_MSG_MAP(CLiteProxyServerApp)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerApp construction

CLiteProxyServerApp::CLiteProxyServerApp()
{
	m_nInProgress = m_nReceivedBytes = m_nCacheBytes = m_nSentBytes = 0;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CLiteProxyServerApp object

CLiteProxyServerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerApp initialization

BOOL CLiteProxyServerApp::InitInstance()
{
	CString strAppUID = "CLiteProxyServerApp";
	
	m_uMsgCheckInst = ::RegisterWindowMessage(strAppUID);

	HANDLE hMutex  = ::CreateMutex(NULL, FALSE, strAppUID);
	DWORD dwError = ::GetLastError();
	if(hMutex != NULL)
	{	// Close mutex handle
		::ReleaseMutex(hMutex);
		// Another instance of application is running:
		if(dwError == ERROR_ALREADY_EXISTS || dwError == ERROR_ACCESS_DENIED)
		{
			DWORD dwReceipents = BSM_APPLICATIONS|BSM_ALLDESKTOPS;
			LONG lRet = ::BroadcastSystemMessage(
				BSF_IGNORECURRENTTASK | BSF_FORCEIFHUNG | BSF_POSTMESSAGE, 
				&dwReceipents, 
				m_uMsgCheckInst, 
				0, 
				0);
			return FALSE;
		}
	}

	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CLiteProxyServerDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CLiteProxyServerView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerApp message handlers

CString Commas(CString str)
{
	int nValue = str.GetLength()-3;
	while(nValue > 0)
		str.Insert(nValue, ','), nValue -= 3;
	return str;
}

CString Commas(int nValue)
{
	CString str;
	str.Format("%d", nValue);
	nValue = str.GetLength()-3;
	while(nValue > 0)
		str.Insert(nValue, ','), nValue -= 3;
	return str;
}

bool CLiteProxyServerApp::GetConnectedState(CString &str)
{
	try
	{
		DWORD dwFlags = 0;
		if(InternetGetConnectedState(&dwFlags, 0) == 0)
		{
			str = "Offline";
			// enable these 2 lines if u want dial up dialog
//			if(InternetAutodial(1, 0) != 0)
//				InternetGetConnectedState(&dwFlags, 0);
			return false;
		}
		if((dwFlags & INTERNET_CONNECTION_MODEM) == INTERNET_CONNECTION_MODEM)
			str = "Modem connection";
		else	if((dwFlags & INTERNET_CONNECTION_LAN) == INTERNET_CONNECTION_LAN)
			str = "LAN connection";
		else	if((dwFlags & INTERNET_CONNECTION_PROXY) == INTERNET_CONNECTION_PROXY)
			str = "Proxy connection";
		else	if((dwFlags & INTERNET_CONNECTION_MODEM_BUSY) == INTERNET_CONNECTION_MODEM_BUSY)
			str = "Modem is busy with a non-Internet connection";
		else	if((dwFlags & 0x10) == 0x10)
			str = "Remote Access Server is installed";
		else	if((dwFlags & 0x20) == 0x20)
			str = "Offline connection";
		else	if((dwFlags & 0x40) == 0x40)
			str = "Internet connection is currently configured";
	}
	catch(...)
	{
		return false;
	}
	return true;
}

BOOL CLiteProxyServerApp::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == m_uMsgCheckInst)
	{
		if( ::IsWindow( m_pMainWnd->GetSafeHwnd() ) )
		{
			// Does the main window have any popups ? If has, 
			// bring the main window or its popup to the top
			// before showing:

			CWnd* pPopupWnd = m_pMainWnd->GetLastActivePopup();
			pPopupWnd->BringWindowToTop();

			// If window is not visible then show it, else if
			// it is iconic, restore it:

			if( !m_pMainWnd->IsWindowVisible() )
				m_pMainWnd->ShowWindow( SW_SHOWNORMAL ); 
			else if( m_pMainWnd->IsIconic() )
				m_pMainWnd->ShowWindow( SW_RESTORE );
			
			// And finally, bring to top after showing again:

			pPopupWnd->BringWindowToTop();
			pPopupWnd->SetForegroundWindow(); 
		}
	}
	
	return CWinApp::PreTranslateMessage(pMsg);
}