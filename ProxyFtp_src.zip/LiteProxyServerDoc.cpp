// LiteProxyServerDoc.cpp : implementation of the CLiteProxyServerDoc class
//

#include "stdafx.h"
#include "LiteProxyServer.h"

#include "LiteProxyServerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerDoc

IMPLEMENT_DYNCREATE(CLiteProxyServerDoc, CDocument)

BEGIN_MESSAGE_MAP(CLiteProxyServerDoc, CDocument)
	//{{AFX_MSG_MAP(CLiteProxyServerDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerDoc construction/destruction

CLiteProxyServerDoc::CLiteProxyServerDoc()
{
	// TODO: add one-time construction code here

}

CLiteProxyServerDoc::~CLiteProxyServerDoc()
{
}

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerDoc serialization

void CLiteProxyServerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerDoc diagnostics

#ifdef _DEBUG
void CLiteProxyServerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CLiteProxyServerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLiteProxyServerDoc commands
