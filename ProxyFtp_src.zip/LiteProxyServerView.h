// LiteProxyServerView.h : interface of the CLiteProxyServerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LITEPROXYSERVERVIEW_H__534938AD_ECF1_11D7_B8FA_0008A1444501__INCLUDED_)
#define AFX_LITEPROXYSERVERVIEW_H__534938AD_ECF1_11D7_B8FA_0008A1444501__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct Request;
struct Listener;

class CLiteProxyServerView : public CListView
{
protected: // create from serialization only
	CLiteProxyServerView();
	DECLARE_DYNCREATE(CLiteProxyServerView)

// Attributes
public:
	CLiteProxyServerDoc* GetDocument();
	CListCtrl* m_pList;
	CImageList m_imageList;
	BOOL	m_bEnsureVisible;

	CStringArray m_strArrayDNS, m_strArrayIP;
	Listener *m_pListener;
// Operations
public:

	int Log(Request* pRequest, LPCSTR lpcsLog);
	void UpdateLog(int nLogID, int nCol, int nLength);
	void UpdateLog(int nLogID, int nCol, LPCSTR lpcs);
	void GetNetworkParams();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLiteProxyServerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLiteProxyServerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLiteProxyServerView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnFileNew();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in LiteProxyServerView.cpp
inline CLiteProxyServerDoc* CLiteProxyServerView::GetDocument()
   { return (CLiteProxyServerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LITEPROXYSERVERVIEW_H__534938AD_ECF1_11D7_B8FA_0008A1444501__INCLUDED_)
