// Request.cpp : implementation file
//

#include "stdafx.h"
#include "LiteProxyServer.h"

#include "Listener.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Listener struct


char *sAppProtocolTypes[] = 
{	"HTTP", 
	"SOCKS4", 
	"SOCKS5", 
	"SMTP Server", 
	"SMTP", 
	"POP3", 
	"FTP", 
	"NNTP", 
	"DNS", 
	"CHAT NS", 
	"",
	"FTP\\PASV",
	"FTP\\PORT",
	"CHAT\\SB", 
	NULL
};

char *sTransProtocolTypes[] = 
{	"TCP", 
	"UDP", 
	"ICMP", 
	"IGMP",
	NULL
};

Listener::Listener()
{
	pThread = NULL;
	nTransProtocol = TYPE_TCP;
}

Listener::~Listener()
{
	StopListen();
}

bool Listener::IsTemp()
{ 
	return nAppProtocol == TYPE_FTP_PASV 
		|| nAppProtocol == TYPE_FTP_PORT; 
}
