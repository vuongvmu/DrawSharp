// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__534938A7_ECF1_11D7_B8FA_0008A1444501__INCLUDED_)
#define AFX_STDAFX_H__534938A7_ECF1_11D7_B8FA_0008A1444501__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxcview.h>
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxsock.h>		// MFC socket extensions
#include "wininet.h"
#include <afxmt.h>

#ifndef __GLOBALALLOC_H_
#define __GLOBALALLOC_H_
#define     GlobalPtrHandle(lp)					((HGLOBAL)GlobalHandle(lp))
#define     GlobalLockPtr(lp)					((BOOL)GlobalLock(GlobalPtrHandle(lp)))
#define     GlobalUnlockPtr(lp)					GlobalUnlock(GlobalPtrHandle(lp))
#define     GlobalAllocPtr(flags, cb)			(GlobalLock(GlobalAlloc((flags), (cb))))
#define     GlobalReAllocPtr(lp, cbNew, flags)	(GlobalUnlockPtr(lp), GlobalLock(GlobalReAlloc(GlobalPtrHandle(lp) , (cbNew), (flags))))
#define     GlobalFreePtr(lp)					(GlobalUnlockPtr(lp), (BOOL)GlobalFree(GlobalPtrHandle(lp)))
#endif  /* !__GLOBALALLOC_H_ */

#define WM_NOTIFY_SOCK	WM_USER+72

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__534938A7_ECF1_11D7_B8FA_0008A1444501__INCLUDED_)
