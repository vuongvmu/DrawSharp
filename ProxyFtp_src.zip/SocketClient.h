#if (!defined(__NEURO__SOCKET__CLIENT__))
#define __NEURO__SOCKET__CLIENT__

#include "SocketEx.h"

class CSocketException : public CException{
public:
	CString m_strError;

	CSocketException(LPCTSTR lpszError,LPCTSTR lpszDetails)
	{
		m_strError = lpszError;
		m_strError += "\n";
		if(lpszDetails)
		{
			m_strError += "System Error Detail:";
			m_strError += lpszDetails;
		}
	}

	BOOL GetErrorMessage(LPTSTR lpszError,UINT nMaxError, PUINT pnHelpContext = NULL)
	{
		strncpy(lpszError,(LPCTSTR)m_strError,nMaxError);
		return true;
	}
};











/************************************************************************
		 
		 Name   : CSocketClient
		 Type   : Class
------------------------------------------------------------------------
		 Author : Akash Kava
		 Purpose: Client socket derived from CSocketEx and introduces 
		          Exception to rise when Data is unavailable or timedout

				  CSocketEx does not throw any exception at all.
************************************************************************/

class CSocketClient : protected CSocketEx{
public:

	CSocketClient()
		: CSocketEx()
	{
		Create(0,NULL);
		
	}

	void Close()
	{
		CSocketEx::Close();
	}

	void ConnectTo(LPCTSTR lpszHost , int nPort)
	{
		if(!Connect(lpszHost,nPort))
			throw new CSocketException(CString("Could not connect to server ") + CString(lpszHost),GetLastError());
	}

	unsigned __int8  ReadInt8()
	{
		unsigned __int8 data;
		if(Receive(&data,1) != 1)
			throw new CSocketException("Error readint socket data",GetLastError());
		return data;
	}

	unsigned __int16 ReadInt16()
	{
		unsigned __int16 data;
		if(Receive(&data,2) != 2)
			throw new CSocketException("Error reading socket data",GetLastError());
		data = ntohs(data);
		return data;
	}

	unsigned __int32 ReadInt32()
	{
		unsigned __int32 data;
		if(Receive(&data,4)!=4)
			throw new CSocketException("Error reading socket data",GetLastError());
		data = ntohl(data);
		return data;
	}

	void WriteInt8(unsigned __int8 data)
	{
		if(Send(&data,1)!=1)
			throw new CSocketException("Error writing socket data",GetLastError());
	}

	void WriteInt16(unsigned __int16 data)
	{
		data = htons(data);
		if(Send(&data,2)!=2)
			throw new CSocketException("Error writing socket data",GetLastError());
	}

	void WriteInt32(unsigned __int32 data)
	{
		data = htonl(data);
		if(Send(&data,4)!=4)
			throw new CSocketException("Error writing socket data",GetLastError());
	}

	void WriteBytes (void * Buffer, int Length)
	{
		if(Send(Buffer,Length)!=Length)
			throw new CSocketException("Error writing socket data",GetLastError());
	}

	void ReadBytes (void * Buffer , int Length)
	{
		if(Receive(Buffer,Length)!=Length)
			throw new CSocketException("Error reading socket data",GetLastError());
	}

};
#endif