// LiteProxyServerDoc.h : interface of the CLiteProxyServerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LITEPROXYSERVERDOC_H__534938AB_ECF1_11D7_B8FA_0008A1444501__INCLUDED_)
#define AFX_LITEPROXYSERVERDOC_H__534938AB_ECF1_11D7_B8FA_0008A1444501__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CLiteProxyServerDoc : public CDocument
{
protected: // create from serialization only
	CLiteProxyServerDoc();
	DECLARE_DYNCREATE(CLiteProxyServerDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLiteProxyServerDoc)
	public:
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLiteProxyServerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CLiteProxyServerDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LITEPROXYSERVERDOC_H__534938AB_ECF1_11D7_B8FA_0008A1444501__INCLUDED_)
