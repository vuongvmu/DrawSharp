// Request.cpp : implementation file
//

#include "stdafx.h"
#include "LiteProxyServer.h"

#include "Request.h"
#include "Listener.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Request struct

Request::Request()
{
	nLogID = -1;
	nRefCount = 2;
	pFileCache = NULL;
	bCheckBlocking = true;
	nAppProtocol = Listener::ApplicationProtocol::TYPE_HTTP;
	nSent = nReceived = 0;
	bLogRequest = FALSE;
	pListener = NULL;
	bRequestServer = true;
	nLength = 0;
	nTime = 0;
}

Request::~Request()
{
	for(int nHost = 0; nHost < dwArrayHosts.GetSize(); nHost++)
	{
		SOCKET SocketHost = dwArrayHosts[nHost];
		shutdown(SocketHost, 2);
		closesocket(SocketHost);
	}
	if(pListener && pListener->IsTemp())
	{
		POSITION pos = gptrArryTempListeners.Find(pListener);
		if(pos)
			gptrArryTempListeners.RemoveAt(pos);
		delete pListener;
	}
}

