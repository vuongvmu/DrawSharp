# MegaDumper
Dump native and .NET assemblies
# How to clone
## Regular branch:
git clone https://github.com/CodeCracker-Tools/MegaDumper MegaDumper
## Filter mod by sleeyax
git clone https://github.com/CodeCracker-Tools/MegaDumper MegaDumper -b filter-mod
