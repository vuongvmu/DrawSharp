﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;

namespace howto_clip_image_to_polygon
{
    public class PolygonEventArgs
    {
        public List<Point> Points;
        public PolygonEventArgs(List<Point> points)
        {
            Points = points;
        }
    }
}
