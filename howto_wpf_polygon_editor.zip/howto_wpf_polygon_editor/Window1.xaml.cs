﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace howto_wpf_polygon_editor
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private Polyline NewPolyline = null;

        private void canDraw_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (radNew.IsChecked.Value) ModeNew_MouseDown(sender, e);
            else ModeEdit_MouseDown(sender, e);
        }
        private void canDraw_MouseMove(object sender, MouseEventArgs e)
        {
            if (radNew.IsChecked.Value) ModeNew_MouseMove(sender, e);
            else ModeEdit_MouseMove(sender, e);
        }

        private void ModeNew_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // See which button was pressed.
            if (e.RightButton == MouseButtonState.Pressed)
            {
                FinishPolygon();
                return;
            }

            // If we don't have a new polygon, start one.
            if (NewPolyline == null)
            {
                // We have no new polygon. Start one.
                NewPolyline = new Polyline();
                NewPolyline.Stroke = Brushes.Red;
                NewPolyline.StrokeThickness = 1;
                NewPolyline.StrokeDashArray = new DoubleCollection();
                NewPolyline.StrokeDashArray.Add(5);
                NewPolyline.StrokeDashArray.Add(5);
                NewPolyline.Points.Add(e.GetPosition(canDraw));
                canDraw.Children.Add(NewPolyline);
            }

            // Add a point to the new polygon.
            NewPolyline.Points.Add(e.GetPosition(canDraw));
        }
        private void ModeNew_MouseMove(object sender, MouseEventArgs e)
        {
            if (NewPolyline == null) return;
            NewPolyline.Points[NewPolyline.Points.Count - 1] = e.GetPosition(canDraw);
        }

        private bool Editing = false;
        private Extensions.PolygonHitTypes
            EditPolygonHitType =
                Extensions.PolygonHitTypes.None;
        private Polygon EditPolygon = null;
        private int EditPolygonPartIndex = -1;
        private Point EditLastPoint = new Point(
            double.NegativeInfinity, double.NegativeInfinity);

        private void ModeEdit_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // See if we are over a polygon.
            if (EditPolygon == null) return;

            EditLastPoint = e.GetPosition(canDraw);
            Editing = true;
            canDraw.CaptureMouse();
        }

        private void ModeEdit_MouseMove(object sender, MouseEventArgs e)
        {
            if (Editing)
            {
                if (EditPolygonHitType == Extensions.PolygonHitTypes.Vertex)
                {
                    // Move the vertex.
                    MoveVertex(e);
                }
                else if (EditPolygonHitType == Extensions.PolygonHitTypes.Edge)
                {
                    // Move the polygon.
                    MovePolygon(e);
                }
            }
            else
            {
                Cursor new_cursor = null;

                // See if we're over a Polygon.
                SetEditPolygon(e.GetPosition(canDraw));
                if (EditPolygonHitType == Extensions.PolygonHitTypes.Vertex)
                {
                    new_cursor = Cursors.Cross;
                }
                else if (EditPolygonHitType == Extensions.PolygonHitTypes.Edge)
                {
                    new_cursor = Cursors.SizeAll;
                }

                // Update the cursor.
                if (canDraw.Cursor != new_cursor)
                    canDraw.Cursor = new_cursor;
            }
        }

        // Move the editing vertex.
        private void MoveVertex(MouseEventArgs e)
        {
            Point cur_point = e.GetPosition(canDraw);
            double dx = cur_point.X - EditLastPoint.X;
            double dy = cur_point.Y - EditLastPoint.Y;
            Point new_point = new Point(
                EditPolygon.Points[EditPolygonPartIndex].X + dx,
                EditPolygon.Points[EditPolygonPartIndex].Y + dy);
            EditPolygon.Points[EditPolygonPartIndex] = new_point;
            EditLastPoint = cur_point;
        }

        // Move the editing polygon.
        private void MovePolygon(MouseEventArgs e)
        {
            Point cur_point = e.GetPosition(canDraw);
            double dx = cur_point.X - EditLastPoint.X;
            double dy = cur_point.Y - EditLastPoint.Y;

            int num_points = EditPolygon.Points.Count;
            for (int i = 0; i < num_points; i++)
            {
                Point new_point = new Point(
                    EditPolygon.Points[i].X + dx,
                    EditPolygon.Points[i].Y + dy);
                EditPolygon.Points[i] = new_point;
            }
            EditLastPoint = cur_point;
        }

        // See if a polygon is at this point.
        // Set EditPolygon, EditPolygonHitType, and
        // EditPolygonPartIndex.
        private void SetEditPolygon(Point point)
        {
            EditPolygon = null;
            EditPolygonHitType = Extensions.PolygonHitTypes.None;
            EditPolygonPartIndex = -1;

            // See if we're over a Polygon.
            foreach (UIElement element in canDraw.Children)
            {
                Polygon polygon = element as Polygon;
                if (polygon == null) continue;

                if (polygon.IsAt(point, out EditPolygonHitType,
                    out EditPolygonPartIndex))
                {
                    EditPolygon = polygon;
                    return;
                }
            }
        }

        private void canDraw_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Editing = false;
            canDraw.ReleaseMouseCapture();
        }

        // If we're making a new Polygon, finish it.
        private void radEdit_Click(object sender, RoutedEventArgs e)
        {
            FinishPolygon();
        }

        private void FinishPolygon()
        {
            // See if we are drawing a new polygon.
            if (NewPolyline == null) return;

            // Only save the polygon if it has at least three
            // points not counting the provisional point.
            if (NewPolyline.Points.Count > 3)
            {
                // Remove the provisional point.
                NewPolyline.Points.RemoveAt(NewPolyline.Points.Count - 1);

                // Convert the new polyline into a polygon.
                Polygon new_polygon = new Polygon();
                new_polygon.Stroke = Brushes.Blue;
                new_polygon.StrokeThickness = 2;
                new_polygon.Points = NewPolyline.Points;
                canDraw.Children.Add(new_polygon);
            }

            // Remove the temporary polyline.
            canDraw.Children.Remove(NewPolyline);
            NewPolyline = null;
        }
    }
}
